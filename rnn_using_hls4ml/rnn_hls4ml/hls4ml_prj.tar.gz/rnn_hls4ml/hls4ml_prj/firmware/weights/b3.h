//Numpy array shape [10]
//Min -0.311664462090
//Max 0.430884450674
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[10];
#else
model_default_t b3[10] = {-0.0485017225, 0.4308844507, 0.1267225146, -0.0713609830, 0.0259903800, -0.0181793720, -0.2797910273, 0.3543926775, -0.3116644621, -0.1458585560};
#endif

#endif
